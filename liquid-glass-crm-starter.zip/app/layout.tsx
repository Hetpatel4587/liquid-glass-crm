import './globals.css'
import React from 'react'

export const metadata = {
  title: 'Business Glass — Demo',
  description: 'Business management app with liquid-glass UI',
}

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="en" data-theme="dark">
      <body>
        <div style={{padding:20}}>
          {children}
        </div>
      </body>
    </html>
  )
}
