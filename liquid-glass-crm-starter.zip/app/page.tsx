import React from 'react';
import GlassCard from '../components/GlassCard';
import KPI from '../components/KPI';
import QuickActions from '../components/QuickActions';

export default function Page() {
  return (
    <main className="max-w-7xl mx-auto">
      <header className="flex items-center justify-between mb-6">
        <h1 className="text-3xl font-semibold">Dashboard</h1>
        <div className="flex gap-3">
          <button className="px-4 py-2 rounded-md glass">New Invoice</button>
          <button className="px-4 py-2 rounded-md glass">New Project</button>
        </div>
      </header>

      <section className="grid grid-cols-1 md:grid-cols-4 gap-6 mb-6">
        <KPI title="Revenue" value="$124,320" change="+6.4%" />
        <KPI title="Expenses" value="$32,110" change="-2.1%" />
        <KPI title="Active Projects" value="12" change="+1" />
        <KPI title="Open Leads" value="48" change="+8" />
      </section>

      <section className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <GlassCard title="Tasks">
          <QuickActions />
        </GlassCard>

        <GlassCard title="Sales">
          <p>Revenue chart placeholder (implement chart lib)</p>
        </GlassCard>

        <GlassCard title="Recent Activity">
          <ul className="space-y-2">
            <li className="text-sm">Invoice #1023 paid — $1,200</li>
            <li className="text-sm">New lead: ACME Corp.</li>
            <li className="text-sm">Timesheet submitted — John</li>
          </ul>
        </GlassCard>
      </section>
    </main>
  )
}
