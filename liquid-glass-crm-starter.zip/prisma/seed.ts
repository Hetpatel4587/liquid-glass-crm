import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main(){
  console.log('Seeding demo data...')
  const c = await prisma.company.create({ data: { name: 'ACME Corp' } })
  await prisma.user.createMany({ data: [
    { email: 'owner@example.com', name: 'Owner', role: 'Owner' },
    { email: 'admin@example.com', name: 'Admin', role: 'Admin' },
    { email: 'staff@example.com', name: 'Staff', role: 'Staff' }
  ]})
  await prisma.lead.create({ data: { name: 'Jane Doe', email: 'jane@acme.com', companyId: c.id } })
  console.log('Seed complete')
}

main().catch(e => { console.error(e); process.exit(1) }).finally(async ()=>{ await prisma.$disconnect() })
