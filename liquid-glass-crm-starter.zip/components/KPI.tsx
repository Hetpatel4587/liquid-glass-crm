import React from 'react';
export default function KPI({title,value,change}:{title:string,value:string,change:string}) {
  return (
    <div className="glass p-4 flex flex-col">
      <span className="text-sm text-zinc-400">{title}</span>
      <div className="mt-2 flex items-baseline justify-between">
        <span className="text-2xl font-semibold">{value}</span>
        <span className="text-sm text-zinc-300">{change}</span>
      </div>
    </div>
  )
}
