import React from 'react';
import { motion } from 'framer-motion';

export default function GlassCard({ title, children }: { title?: string, children: React.ReactNode }) {
  return (
    <motion.article
      initial={{ y:8, opacity:0 }}
      animate={{ y:0, opacity:1 }}
      transition={{ duration:0.28, ease:'easeOut' }}
      className="glass p-4"
    >
      {title && <h3 className="text-lg font-medium mb-3">{title}</h3>}
      <div>
        {children}
      </div>
    </motion.article>
  )
}
