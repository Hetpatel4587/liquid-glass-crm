import React from 'react';
export default function QuickActions(){
  return (
    <div className="space-y-3">
      <button className="w-full py-2 rounded-md glass hover:scale-[1.01] transition-transform">Create Task</button>
      <button className="w-full py-2 rounded-md glass hover:scale-[1.01] transition-transform">Add Lead</button>
      <button className="w-full py-2 rounded-md glass hover:scale-[1.01] transition-transform">New Invoice</button>
    </div>
  )
}
